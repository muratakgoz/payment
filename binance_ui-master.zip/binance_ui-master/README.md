## Binance Application :office: :chart:

### Description:

- Application clone from Binance JEX real app. Just have UI/UX, you can clone this repository and customize it.

### How I can run it?

- :rocket: run ***flutter pub get*** on terminal in project
- :rocket: run this app on **Android** or **IOS**.

### Screenshots

<p> 
<img src="https://github.com/hongvinhmobile/binance_ui/blob/master/screenshots/c86c9ec1d2961bc842871.jpg" width="200px"/>
<img src="https://github.com/hongvinhmobile/binance_ui/blob/master/screenshots/c882ca2f86784f2616694.jpg" width="200px"/>
<img src="https://github.com/hongvinhmobile/binance_ui/blob/master/screenshots/f1e6874bcb1c02425b0d2.jpg" width="200px"/>
<img src="https://github.com/hongvinhmobile/binance_ui/blob/master/screenshots/daa6b20bfe5c37026e4d3.jpg" width="200px"/>
</p>
