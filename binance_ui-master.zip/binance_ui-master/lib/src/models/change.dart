class Change {
  final String title;
  final double value;
  final double percent;
  final bool increase;

  Change({this.title, this.value, this.percent, this.increase});
}

List<Change> changes = [
  Change(title: 'BTC0106CALLD', value: 15.8096, percent: 71.88, increase: true),
  Change(title: 'BTC0106CALLD', value: 15.8096, percent: 71.88, increase: true),
  Change(title: 'BTC0106CALLD', value: 15.8096, percent: 71.88, increase: true),
  Change(title: 'BTC0106CALLD', value: 15.8096, percent: 71.88, increase: true),
  Change(title: 'BTC0106CALLD', value: 15.8096, percent: 71.88, increase: true),
  Change(title: 'BTC0106CALLD', value: 15.8096, percent: 71.88, increase: true),
];
