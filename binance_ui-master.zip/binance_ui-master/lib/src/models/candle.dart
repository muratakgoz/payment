class Candle {
  final double open;
  final double high;
  final double low;
  final double close;
  final double volumeto;

  Candle({this.open, this.high, this.low, this.close, this.volumeto});
}
